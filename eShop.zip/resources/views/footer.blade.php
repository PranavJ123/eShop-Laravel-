<div style="clear:both" class="panel panel-default">
  <div class="panel-body">
  Copyright © 2021 eShop.com|All Rights Reserved
  </div>
</div>